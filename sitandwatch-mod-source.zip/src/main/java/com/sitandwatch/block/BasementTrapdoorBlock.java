package com.sitandwatch.block;

import com.sitandwatch.world.StoryManager;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.phys.BlockHitResult;

/** Trapdoor to the basement. The story locks it shut in the Night 4 climax. */
public class BasementTrapdoorBlock extends TrapDoorBlock {
    public BasementTrapdoorBlock(Properties props, BlockSetType type) {
        super(props, type);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (level instanceof ServerLevel sl && StoryManager.isTrapdoorLocked(sl, pos)) {
            level.playSound(null, pos, SoundEvents.CHEST_LOCKED, SoundSource.BLOCKS, 1.0f, 0.6f);
            return InteractionResult.FAIL;
        }
        if (level.isClientSide && player.getVehicle() != null && player.getVehicle().getType() == com.sitandwatch.registry.ModEntities.CHAIR_SEAT.get()) {
            return InteractionResult.FAIL;
        }
        return super.use(state, level, pos, player, hand, hit);
    }
}
