package com.sitandwatch.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.sitandwatch.SitAndWatch;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/** Story subtitle + blood splatter overlay. */
public class HudOverlay {
    private static final ResourceLocation BLOOD = new ResourceLocation(SitAndWatch.MOD_ID, "textures/gui/blood.png");
    private static final int BLOOD_W = 1024, BLOOD_H = 702;

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (ClientState.bloodTicks > 0) {
            float f = Mth.clamp((ClientState.bloodTicks - partialTick) / (float) ClientState.bloodMax * 1.8f, 0f, 1f);
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            g.setColor(1f, 1f, 1f, f * 0.92f);
            g.blit(BLOOD, 0, 0, w, h, 0, 0, BLOOD_W, BLOOD_H, BLOOD_W, BLOOD_H);
            g.setColor(1f, 1f, 1f, 1f);
            RenderSystem.disableBlend();
        }
        if (ClientState.subTicks > 0 && !ClientState.subKey.isEmpty()) {
            float f = Mth.clamp(Math.min(ClientState.subTicks, ClientState.subMax - ClientState.subTicks + 10) / 10f, 0f, 1f);
            int alpha = Mth.clamp((int) (255 * f), 8, 255);
            Component text = Component.translatable(ClientState.subKey);
            var pose = g.pose();
            pose.pushPose();
            pose.translate(w / 2f, h * 0.70f, 0);
            pose.scale(2.0f, 2.0f, 1.0f);
            if (ClientState.subDistorted) {
                float t = mc.player != null ? mc.player.tickCount : 0;
                float j = Mth.sin(t * 1.7f) * 1.5f;
                g.drawCenteredString(mc.font, text, (int) j, 0, (alpha / 2 << 24) | 0xFF2020);
                g.drawCenteredString(mc.font, text, (int) -j, 1, (alpha / 2 << 24) | 0x20E0FF);
            }
            g.drawCenteredString(mc.font, text, 0, 0, (alpha << 24) | 0xFFFFFF);
            pose.popPose();
        }
    }
}
