package com.sitandwatch.client;

import com.sitandwatch.network.EffectPacket;
import com.sitandwatch.registry.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.sounds.SoundSource;

/** Client-side story state mirrored from the server through packets. */
public class ClientState {
    public static boolean locked;
    public static float lockYaw, lockPitch;

    public static String subKey = "";
    public static int subTicks, subMax;
    public static boolean subDistorted;

    public static int bloodTicks, bloodMax;
    public static boolean ambience;
    private static LoopingSound ambienceSound;

    public static void setLock(boolean l, float yaw, float pitch) {
        locked = l;
        lockYaw = yaw;
        lockPitch = pitch;
        Minecraft mc = Minecraft.getInstance();
        if (l && mc.player != null) {
            mc.player.setYRot(yaw);
            mc.player.setXRot(pitch);
            mc.player.yRotO = yaw;
            mc.player.xRotO = pitch;
        }
    }

    public static void showSubtitle(String key, int ticks, boolean distorted) {
        subKey = key;
        subTicks = subMax = ticks;
        subDistorted = distorted;
    }

    public static void nudge(float dYaw, float dPitch) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        mc.player.setYRot(mc.player.getYRot() + dYaw);
        mc.player.setXRot(mc.player.getXRot() + dPitch);
    }

    public static void effect(int type, int arg) {
        switch (type) {
            case EffectPacket.BLOOD -> { bloodTicks = bloodMax = Math.max(1, arg); }
            case EffectPacket.AMBIENCE_START -> {
                ambience = true;
                ambienceSound = new LoopingSound(ModSounds.AMBIENCE_LOOP.get(), SoundSource.AMBIENT, () -> ambience, () -> 0.9f);
                Minecraft.getInstance().getSoundManager().play(ambienceSound);
            }
            case EffectPacket.AMBIENCE_STOP -> ambience = false;
            default -> { }
        }
    }

    public static void tick() {
        if (subTicks > 0) subTicks--;
        if (bloodTicks > 0) bloodTicks--;
    }
}
