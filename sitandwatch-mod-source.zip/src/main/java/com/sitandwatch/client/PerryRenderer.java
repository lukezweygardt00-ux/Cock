package com.sitandwatch.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.sitandwatch.SitAndWatch;
import com.sitandwatch.entity.PerryEntity;
import net.minecraft.client.model.WolfModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Perry: vanilla wolf geometry with a creepy bloodshot-eyed, red-collared texture and subtle twitching. */
public class PerryRenderer extends MobRenderer<PerryEntity, WolfModel<PerryEntity>> {
    private static final ResourceLocation TEX = new ResourceLocation(SitAndWatch.MOD_ID, "textures/entity/perry_wolf.png");

    public PerryRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new WolfModel<>(ctx.bakeLayer(ModelLayers.WOLF)), 0.5f);
    }

    @Override
    protected float getBob(PerryEntity wolf, float partialTick) {
        return wolf.getTailAngle();
    }

    @Override
    protected void setupRotations(PerryEntity e, PoseStack ps, float bob, float yBodyRot, float partialTick) {
        super.setupRotations(e, ps, bob, yBodyRot, partialTick);
        if (e.tickCount % 37 < 3) {
            ps.mulPose(Axis.ZP.rotationDegrees(Mth.sin(e.tickCount * 9.0f) * 1.8f));
        }
    }

    @Override
    public ResourceLocation getTextureLocation(PerryEntity e) {
        return TEX;
    }
}
