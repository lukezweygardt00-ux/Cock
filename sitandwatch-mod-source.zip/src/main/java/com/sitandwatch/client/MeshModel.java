package com.sitandwatch.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.sitandwatch.entity.StoryVillager;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

/** Generic model that draws a baked Blockbench mesh and animates it per named part. */
public class MeshModel<T extends StoryVillager> extends EntityModel<T> {
    private final String meshName;
    private float headYaw, headPitch, limb, limbAmt, age;
    private int gesture, pose;

    public MeshModel(String meshName) {
        super(RenderType::entityCutoutNoCull);
        this.meshName = meshName;
    }

    @Override
    public void setupAnim(T e, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.limb = limbSwing;
        this.limbAmt = limbSwingAmount;
        this.age = ageInTicks;
        this.headYaw = netHeadYaw * Mth.DEG_TO_RAD;
        this.headPitch = headPitch * Mth.DEG_TO_RAD;
        this.gesture = e.getGesture();
        this.pose = e.getPoseState();
    }

    @Override
    public void renderToBuffer(PoseStack ps, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        MeshData data = MeshData.get(meshName);
        float[] rot = new float[5]; // xRot, yRot, zRot, dx, dy
        float shake = pose == StoryVillager.P_SHIVER ? Mth.sin(age * 3.3f) * 0.012f : 0f;
        for (MeshData.Part p : data.parts) {
            animate(p.name, rot);
            ps.pushPose();
            ps.translate(p.px + rot[3] + shake, p.py + rot[4], p.pz);
            if (rot[0] != 0f || rot[1] != 0f || rot[2] != 0f) {
                ps.mulPose(new Quaternionf().rotationZYX(rot[2], rot[1], rot[0]));
            }
            ps.translate(-p.px, -p.py, -p.pz);
            PoseStack.Pose last = ps.last();
            Matrix4f m = last.pose();
            Matrix3f n = last.normal();
            float[] v = p.v;
            for (int i = 0, o = 0; i < p.count; i++, o += 8) {
                vc.vertex(m, v[o], v[o + 1], v[o + 2]).color(r, g, b, a).uv(v[o + 3], v[o + 4])
                        .overlayCoords(overlay).uv2(light).normal(n, v[o + 5], v[o + 6], v[o + 7]).endVertex();
            }
            ps.popPose();
        }
    }

    private void animate(String part, float[] o) {
        o[0] = o[1] = o[2] = o[3] = o[4] = 0f;
        float t = age;
        switch (part) {
            case "head" -> {
                o[1] = headYaw;
                o[0] = headPitch;
                if (pose == StoryVillager.P_SHIVER) o[0] += 0.25f;
                if (pose == StoryVillager.P_FAINTED) o[0] += 0.55f;
                if (pose == StoryVillager.P_TRAPPED) o[0] += 0.35f;
                if (gesture == StoryVillager.G_LAUGH) o[0] += -0.35f + Mth.sin(t * 1.3f) * 0.22f;
                if (gesture == StoryVillager.G_ANGRY) o[0] += 0.2f;
            }
            case "rleg" -> o[0] = Mth.cos(limb * 0.6662f) * 1.4f * limbAmt;
            case "lleg" -> o[0] = Mth.cos(limb * 0.6662f + Mth.PI) * 1.4f * limbAmt;
            case "rarm" -> {
                switch (gesture) {
                    case StoryVillager.G_WAVE -> { o[0] = -2.5f; o[2] = Mth.sin(t * 0.7f) * 0.45f; }
                    case StoryVillager.G_POINT -> o[0] = -1.55f;
                    case StoryVillager.G_FLEX -> { o[0] = -0.6f; o[2] = -1.0f; }
                    case StoryVillager.G_GRAB -> o[0] = -1.3f;
                    case StoryVillager.G_LAUGH -> o[0] = -0.3f + Mth.sin(t * 1.3f) * 0.15f;
                    case StoryVillager.G_ANGRY -> o[0] = -1.2f + Mth.sin(t * 1.6f) * 0.3f;
                    default -> { }
                }
            }
            case "larm" -> {
                switch (gesture) {
                    case StoryVillager.G_FLEX -> { o[0] = -0.6f; o[2] = 1.0f; }
                    case StoryVillager.G_LAUGH -> o[0] = -0.3f + Mth.sin(t * 1.3f + 1f) * 0.15f;
                    case StoryVillager.G_ANGRY -> o[0] = -1.2f + Mth.sin(t * 1.6f + 2f) * 0.3f;
                    default -> { }
                }
            }
            case "arms" -> {
                if (gesture == StoryVillager.G_WAVE || gesture == StoryVillager.G_FLEX || gesture == StoryVillager.G_ANGRY) o[4] = 0.0f;
            }
            default -> {
                if (gesture == StoryVillager.G_LAUGH) o[4] = -Math.abs(Mth.sin(t * 1.3f)) * 0.03f;
            }
        }
    }
}
