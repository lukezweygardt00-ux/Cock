package com.sitandwatch.client;

import com.sitandwatch.SitAndWatch;
import com.sitandwatch.entity.SmugBroEntity;
import com.sitandwatch.entity.SocialVillagerEntity;
import com.sitandwatch.registry.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

@Mod.EventBusSubscriber(modid = SitAndWatch.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class ClientEvents {
    private static boolean crowdActive;
    private static float crowdVolume;
    private static LoopingSound theme;

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        ClientState.tick();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) {
            ClientState.locked = false;
            return;
        }
        if (ClientState.locked) {
            p.setYRot(ClientState.lockYaw);
            p.setXRot(ClientState.lockPitch);
            p.yRotO = ClientState.lockYaw;
            p.xRotO = ClientState.lockPitch;
            p.yHeadRot = ClientState.lockYaw;
            p.yHeadRotO = ClientState.lockYaw;
            p.yBodyRot = ClientState.lockYaw;
            p.yBodyRotO = ClientState.lockYaw;
        }
        if (p.tickCount % 10 == 0) updateCrowd(mc, p);
        if (crowdActive && (theme == null || theme.isStopped())) {
            theme = new LoopingSound(ModSounds.SMUG_THEME.get(), SoundSource.MUSIC, () -> crowdActive, () -> crowdVolume);
            mc.getSoundManager().play(theme);
        }
    }

    /** The happy theme only plays while fans are circling Smug Bro, not while walking around with him. */
    private static void updateCrowd(Minecraft mc, LocalPlayer p) {
        crowdActive = false;
        crowdVolume = 0f;
        List<SmugBroEntity> smugs = mc.level.getEntitiesOfClass(SmugBroEntity.class, p.getBoundingBox().inflate(48));
        for (SmugBroEntity s : smugs) {
            int fans = mc.level.getEntitiesOfClass(SocialVillagerEntity.class, s.getBoundingBox().inflate(9.0), SocialVillagerEntity::isObsessed).size();
            if (fans >= 3) {
                crowdActive = true;
                crowdVolume = Math.max(crowdVolume, Mth.clamp(1.0f - (float) p.distanceTo(s) / 48f, 0.08f, 1.0f));
            }
        }
    }

    @SubscribeEvent
    public static void onInput(MovementInputUpdateEvent e) {
        if (!ClientState.locked) return;
        var in = e.getInput();
        in.forwardImpulse = 0f;
        in.leftImpulse = 0f;
        in.up = in.down = in.left = in.right = false;
        in.jumping = false;
        in.shiftKeyDown = false;
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles e) {
        if (!ClientState.locked) return;
        e.setYaw(ClientState.lockYaw);
        e.setPitch(ClientState.lockPitch);
        e.setRoll(0f);
    }
}
