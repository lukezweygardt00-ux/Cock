package com.sitandwatch.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

import java.util.List;

/**
 * Perry: tamed with bones like a normal wolf, but once Smug Bro's mansion exists he walks to Smug Bro,
 * sits beside him and ignores the player.
 */
public class PerryEntity extends Wolf {
    private boolean betrayed;

    public PerryEntity(EntityType<? extends Wolf> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public boolean isBetrayed() { return betrayed; }

    /** Called by the story once the mansion appears. */
    public void betray() {
        betrayed = true;
        this.setOwnerUUID(null);
        this.setOrderedToSit(false);
        this.setInSittingPose(false);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide || !betrayed || tickCount % 20 != 0) return;
        List<SmugBroEntity> smugs = level().getEntitiesOfClass(SmugBroEntity.class, new AABB(blockPosition()).inflate(96));
        if (smugs.isEmpty()) return;
        SmugBroEntity smug = smugs.get(0);
        if (distanceToSqr(smug) > 6.0) {
            this.setInSittingPose(false);
            this.setOrderedToSit(false);
            this.getNavigation().moveTo(smug.getX() + 1.2, smug.getY(), smug.getZ() + 0.4, 1.3);
        } else {
            this.getNavigation().stop();
            this.setOrderedToSit(true);
            this.setInSittingPose(true);
            this.getLookControl().setLookAt(smug);
        }
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (betrayed) return InteractionResult.PASS; // ignores the player completely
        return super.mobInteract(player, hand);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Betrayed", betrayed);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        betrayed = tag.getBoolean("Betrayed");
    }
}
