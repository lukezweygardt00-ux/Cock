package com.sitandwatch.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.ForgeRegistries;

import javax.annotation.Nullable;
import java.util.UUID;

/** Ron: timid villager. Shivers until befriended with cooked food, then follows the player. */
public class RonEntity extends StoryVillager {
    @Nullable private UUID owner;

    public RonEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setInvulnerable(true);
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        this.goalSelector.addGoal(3, new FollowFriendGoal(this));
    }

    @Nullable public UUID getOwner() { return owner; }
    public boolean isBefriended() { return owner != null; }

    private static boolean isCookedFood(ItemStack s) {
        if (!s.isEdible()) return false;
        if (s.is(Items.BREAD) || s.is(Items.BAKED_POTATO) || s.is(Items.PUMPKIN_PIE) || s.is(Items.COOKIE)) return true;
        var key = ForgeRegistries.ITEMS.getKey(s.getItem());
        return key != null && key.getPath().startsWith("cooked_");
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (owner == null && getPoseState() != P_FAINTED && isCookedFood(stack)) {
            if (!level().isClientSide) {
                if (!player.getAbilities().instabuild) stack.shrink(1);
                owner = player.getUUID();
                setPoseState(P_NORMAL);
                ((ServerLevel) level()).sendParticles(ParticleTypes.HEART, getX(), getY() + 1.8, getZ(), 8, 0.4, 0.3, 0.4, 0.02);
                talk();
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (owner != null) tag.putUUID("Friend", owner);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        owner = tag.hasUUID("Friend") ? tag.getUUID("Friend") : null;
    }

    /** Follow the befriended player, staying close for protection. */
    private static class FollowFriendGoal extends Goal {
        private final RonEntity ron;
        private Player friend;
        private int cooldown;

        FollowFriendGoal(RonEntity ron) {
            this.ron = ron;
            this.setFlags(java.util.EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (ron.owner == null || ron.getPoseState() == P_FAINTED || ron.getPoseState() == P_TRAPPED || ron.hasMoveTarget()) return false;
            friend = ron.level().getPlayerByUUID(ron.owner);
            return friend != null && ron.distanceToSqr(friend) > 9.0;
        }

        @Override
        public boolean canContinueToUse() {
            return friend != null && friend.isAlive() && ron.distanceToSqr(friend) > 4.0 && !ron.hasMoveTarget();
        }

        @Override
        public void tick() {
            ron.getLookControl().setLookAt(friend, 30f, 30f);
            if (--cooldown <= 0) {
                cooldown = 10;
                if (ron.distanceToSqr(friend) > 400.0) {
                    ron.teleportTo(friend.getX(), friend.getY(), friend.getZ());
                } else {
                    ron.getNavigation().moveTo(friend, 1.15);
                }
            }
        }
    }
}
