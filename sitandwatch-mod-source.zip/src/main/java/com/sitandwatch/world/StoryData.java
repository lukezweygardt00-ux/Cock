package com.sitandwatch.world;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.LongTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.level.saveddata.SavedData;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** Persistent progress of the story (Day 1 .. Night 4) for this world. */
public class StoryData extends SavedData {
    public static final String NAME = "sitandwatch_story";

    // progression
    public boolean started;
    public long startDay;
    @Nullable public UUID player, smug, ron, perry, watcher;

    // one-shot flags
    public boolean couchPlacedFlag;
    public boolean fansConverted, smugSpawned, mansionBuilt, perryBetrayed, ronSpawned, partyDone, ronStuffed,
            couchUnzipped, ronWoke, dismissive, mobStarted, mobDone, night4Prepared, climaxStarted, climaxDone;

    // small state machines
    public int phase;          // Smug Bro's current activity on Day 1
    public int lurePhase;      // Day 2 party
    public int day3Phase;      // Day 3 frame-up
    public long phaseStart, lastGrab, unzipTick, partyStart, mobStart;
    public int mobHits;
    public int climaxTick;

    // places
    @Nullable public BlockPos home, site, doorPos, partyPos, trapdoor, chair, ronSpot, smugRoom, couch, square, ringCenter;
    @Nullable public BlockPos basementMin, basementMax;
    public Direction couchFacing = Direction.NORTH;
    public final List<BlockPos> barrier = new ArrayList<>();
    public final Set<Long> lockedTrapdoors = new HashSet<>();

    public StoryData() { }

    public static StoryData load(CompoundTag t) {
        StoryData d = new StoryData();
        d.started = t.getBoolean("started");
        d.startDay = t.getLong("startDay");
        d.player = uuid(t, "player"); d.smug = uuid(t, "smug"); d.ron = uuid(t, "ron");
        d.perry = uuid(t, "perry"); d.watcher = uuid(t, "watcher");
        d.fansConverted = t.getBoolean("fansConverted"); d.smugSpawned = t.getBoolean("smugSpawned");
        d.mansionBuilt = t.getBoolean("mansionBuilt"); d.perryBetrayed = t.getBoolean("perryBetrayed");
        d.ronSpawned = t.getBoolean("ronSpawned"); d.partyDone = t.getBoolean("partyDone");
        d.ronStuffed = t.getBoolean("ronStuffed"); d.couchUnzipped = t.getBoolean("couchUnzipped");
        d.ronWoke = t.getBoolean("ronWoke"); d.dismissive = t.getBoolean("dismissive");
        d.mobStarted = t.getBoolean("mobStarted"); d.mobDone = t.getBoolean("mobDone");
        d.night4Prepared = t.getBoolean("night4Prepared"); d.climaxStarted = t.getBoolean("climaxStarted");
        d.climaxDone = t.getBoolean("climaxDone");
        d.phase = t.getInt("phase"); d.lurePhase = t.getInt("lurePhase"); d.day3Phase = t.getInt("day3Phase");
        d.phaseStart = t.getLong("phaseStart"); d.lastGrab = t.getLong("lastGrab"); d.unzipTick = t.getLong("unzipTick");
        d.partyStart = t.getLong("partyStart"); d.mobStart = t.getLong("mobStart");
        d.mobHits = t.getInt("mobHits"); d.climaxTick = t.getInt("climaxTick");
        d.home = pos(t, "home"); d.site = pos(t, "site"); d.doorPos = pos(t, "doorPos"); d.partyPos = pos(t, "partyPos");
        d.trapdoor = pos(t, "trapdoor"); d.chair = pos(t, "chair"); d.ronSpot = pos(t, "ronSpot");
        d.smugRoom = pos(t, "smugRoom"); d.couch = pos(t, "couch"); d.square = pos(t, "square");
        d.ringCenter = pos(t, "ringCenter"); d.basementMin = pos(t, "bmin"); d.basementMax = pos(t, "bmax");
        d.couchFacing = Direction.from3DDataValue(t.getInt("couchFacing"));
        if (d.couchFacing.getAxis().isVertical()) d.couchFacing = Direction.NORTH;
        for (Tag e : t.getList("barrier", Tag.TAG_LONG)) d.barrier.add(BlockPos.of(((LongTag) e).getAsLong()));
        for (Tag e : t.getList("locked", Tag.TAG_LONG)) d.lockedTrapdoors.add(((LongTag) e).getAsLong());
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag t) {
        t.putBoolean("started", started); t.putLong("startDay", startDay);
        putUuid(t, "player", player); putUuid(t, "smug", smug); putUuid(t, "ron", ron);
        putUuid(t, "perry", perry); putUuid(t, "watcher", watcher);
        t.putBoolean("fansConverted", fansConverted); t.putBoolean("smugSpawned", smugSpawned);
        t.putBoolean("mansionBuilt", mansionBuilt); t.putBoolean("perryBetrayed", perryBetrayed);
        t.putBoolean("ronSpawned", ronSpawned); t.putBoolean("partyDone", partyDone);
        t.putBoolean("ronStuffed", ronStuffed); t.putBoolean("couchUnzipped", couchUnzipped);
        t.putBoolean("ronWoke", ronWoke); t.putBoolean("dismissive", dismissive);
        t.putBoolean("mobStarted", mobStarted); t.putBoolean("mobDone", mobDone);
        t.putBoolean("night4Prepared", night4Prepared); t.putBoolean("climaxStarted", climaxStarted);
        t.putBoolean("climaxDone", climaxDone);
        t.putInt("phase", phase); t.putInt("lurePhase", lurePhase); t.putInt("day3Phase", day3Phase);
        t.putLong("phaseStart", phaseStart); t.putLong("lastGrab", lastGrab); t.putLong("unzipTick", unzipTick);
        t.putLong("partyStart", partyStart); t.putLong("mobStart", mobStart);
        t.putInt("mobHits", mobHits); t.putInt("climaxTick", climaxTick);
        putPos(t, "home", home); putPos(t, "site", site); putPos(t, "doorPos", doorPos); putPos(t, "partyPos", partyPos);
        putPos(t, "trapdoor", trapdoor); putPos(t, "chair", chair); putPos(t, "ronSpot", ronSpot);
        putPos(t, "smugRoom", smugRoom); putPos(t, "couch", couch); putPos(t, "square", square);
        putPos(t, "ringCenter", ringCenter); putPos(t, "bmin", basementMin); putPos(t, "bmax", basementMax);
        t.putInt("couchFacing", couchFacing.get3DDataValue());
        ListTag b = new ListTag();
        for (BlockPos p : barrier) b.add(LongTag.valueOf(p.asLong()));
        t.put("barrier", b);
        ListTag l = new ListTag();
        for (long p : lockedTrapdoors) l.add(LongTag.valueOf(p));
        t.put("locked", l);
        return t;
    }

    public void reset() {
        StoryData fresh = new StoryData();
        started = fresh.started; startDay = 0; player = smug = ron = perry = watcher = null;
        fansConverted = smugSpawned = mansionBuilt = perryBetrayed = ronSpawned = partyDone = ronStuffed = couchUnzipped = false;
        ronWoke = dismissive = mobStarted = mobDone = night4Prepared = climaxStarted = climaxDone = false;
        phase = lurePhase = day3Phase = mobHits = climaxTick = 0;
        phaseStart = lastGrab = unzipTick = partyStart = mobStart = 0;
        home = site = doorPos = partyPos = trapdoor = chair = ronSpot = smugRoom = couch = square = ringCenter = null;
        basementMin = basementMax = null;
        barrier.clear();
        lockedTrapdoors.clear();
        setDirty();
    }

    private static UUID uuid(CompoundTag t, String k) { return t.hasUUID(k) ? t.getUUID(k) : null; }
    private static void putUuid(CompoundTag t, String k, @Nullable UUID u) { if (u != null) t.putUUID(k, u); }
    private static BlockPos pos(CompoundTag t, String k) { return t.contains(k, Tag.TAG_LONG) ? BlockPos.of(t.getLong(k)) : null; }
    private static void putPos(CompoundTag t, String k, @Nullable BlockPos p) { if (p != null) t.putLong(k, p.asLong()); }
}
