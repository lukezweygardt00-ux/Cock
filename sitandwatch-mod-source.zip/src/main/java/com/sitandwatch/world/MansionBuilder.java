package com.sitandwatch.world;

import com.sitandwatch.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.level.block.state.properties.SlabType;

/**
 * Programmatically generates Smug Bro's mansion (two floors, gold trim, TV, statue, luxury bed) and the
 * deceptively normal brick basement beneath it with a single wooden chair.
 *
 * Layout (x = 0..16, z = 0..12, door on the south wall z=12, 'base' = ground floor air level):
 *  - ground floor floor-slab at y=base-1, interior air base..base+4
 *  - second floor slab at y=base+5, interior base+6..base+9, roof at base+10
 *  - basement interior y=base-6..base-3, x 3..13, z 2..10, entered through a trapdoor at (13, base-1, 2)
 */
public class MansionBuilder {
    public static final int W = 17, D = 13;

    private static final int F = 2; // setBlock flags: send to clients, no neighbour updates

    private static void set(ServerLevel l, BlockPos o, int x, int y, int z, BlockState s) {
        l.setBlock(o.offset(x, y, z), s, F);
    }

    private static void fill(ServerLevel l, BlockPos o, int x0, int y0, int z0, int x1, int y1, int z1, BlockState s) {
        for (int x = x0; x <= x1; x++)
            for (int y = y0; y <= y1; y++)
                for (int z = z0; z <= z1; z++)
                    set(l, o, x, y, z, s);
    }

    /** o = (min x, ground floor air level, min z) corner of the footprint. */
    public static void build(ServerLevel l, StoryData d, BlockPos o) {
        BlockState air = Blocks.AIR.defaultBlockState();
        BlockState plank = Blocks.BIRCH_PLANKS.defaultBlockState();
        BlockState dark = Blocks.DARK_OAK_PLANKS.defaultBlockState();
        BlockState log = Blocks.STRIPPED_BIRCH_LOG.defaultBlockState();
        BlockState gold = Blocks.GOLD_BLOCK.defaultBlockState();
        BlockState brick = Blocks.STONE_BRICKS.defaultBlockState();
        BlockState pane = Blocks.GLASS_PANE.defaultBlockState();

        // 1. clear the volume + foundation/basement shell
        fill(l, o, -3, 0, -3, W + 2, 14, D + 5, air);
        fill(l, o, 0, -8, 0, W - 1, -1, D - 1, brick); // solid foundation block, carved out below
        // ground floor + second floor slabs
        fill(l, o, 0, -1, 0, W - 1, -1, D - 1, plank);

        // 2. basement room (interior x 3..13, z 2..10, y -6..-3), brick walls, plank floor
        fill(l, o, 2, -7, 1, 14, -2, 11, brick);       // shell
        fill(l, o, 3, -6, 2, 13, -3, 10, air);         // interior
        fill(l, o, 3, -7, 2, 13, -7, 10, plank);       // floor
        fill(l, o, 13, -2, 2, 13, -2, 2, air);         // opening above the ladder column
        for (int y = -6; y <= -2; y++) set(l, o, 13, y, 2, Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, Direction.SOUTH));
        set(l, o, 13, -1, 2, ModBlocks.BASEMENT_TRAPDOOR.get().defaultBlockState()
                .setValue(TrapDoorBlock.FACING, Direction.NORTH).setValue(TrapDoorBlock.HALF, Half.BOTTOM).setValue(TrapDoorBlock.OPEN, false));
        // the chair and Ron's white "bed"
        set(l, o, 8, -6, 6, ModBlocks.WOODEN_CHAIR.get().defaultBlockState().setValue(WoodenChairFacing.FACING, Direction.NORTH));
        fill(l, o, 7, -6, 3, 9, -6, 3, Blocks.WHITE_WOOL.defaultBlockState());
        set(l, o, 6, -6, 8, Blocks.TORCH.defaultBlockState()); // a single dim torch, hidden in a corner

        // 3. ground-floor walls
        for (int y = 0; y <= 4; y++) {
            for (int x = 0; x < W; x++) { set(l, o, x, y, 0, plank); set(l, o, x, y, D - 1, plank); }
            for (int z = 0; z < D; z++) { set(l, o, 0, y, z, plank); set(l, o, W - 1, y, z, plank); }
        }
        // corner/mid pillars
        for (int y = 0; y <= 9; y++) for (int x : new int[]{0, W - 1}) for (int z : new int[]{0, D - 1}) set(l, o, x, y, z, log);
        // second floor slab + stairwell hole, walls
        fill(l, o, 0, 5, 0, W - 1, 5, D - 1, plank);
        fill(l, o, 2, 5, 3, 2, 5, 7, air);
        for (int y = 6; y <= 9; y++) {
            for (int x = 0; x < W; x++) { set(l, o, x, y, 0, plank); set(l, o, x, y, D - 1, plank); }
            for (int z = 0; z < D; z++) { set(l, o, 0, y, z, plank); set(l, o, W - 1, y, z, plank); }
        }
        for (int y = 0; y <= 9; y++) for (int x : new int[]{0, W - 1}) for (int z : new int[]{0, D - 1}) set(l, o, x, y, z, log);
        // windows (glass panes) on all four walls, both floors
        for (int fl : new int[]{1, 7}) {
            for (int x : new int[]{3, 5, 11, 13}) { set(l, o, x, fl, 0, pane); set(l, o, x, fl + 1, 0, pane); set(l, o, x, fl, D - 1, pane); set(l, o, x, fl + 1, D - 1, pane); }
            for (int z : new int[]{3, 6, 9}) { set(l, o, 0, fl, z, pane); set(l, o, 0, fl + 1, z, pane); set(l, o, W - 1, fl, z, pane); set(l, o, W - 1, fl + 1, z, pane); }
        }
        // roof: slab layer + gold ridge
        for (int x = -1; x <= W; x++) for (int z = -1; z <= D; z++)
            set(l, o, x, 10, z, Blocks.DARK_OAK_SLAB.defaultBlockState().setValue(SlabBlock.TYPE, SlabType.BOTTOM));
        fill(l, o, 0, 10, 0, W - 1, 10, D - 1, dark);
        // stairs up (ascending south along x=2)
        for (int i = 0; i < 5; i++)
            set(l, o, 2, i, 3 + i, Blocks.OAK_STAIRS.defaultBlockState().setValue(StairBlock.FACING, Direction.NORTH));
        // door on the south wall
        placeDoor(l, o, 8, D - 1);
        // gold porch pillars + red carpet path
        for (int x : new int[]{6, 10}) fill(l, o, x, 0, D + 1, x, 3, D + 1, gold);
        fill(l, o, 6, 4, D + 1, 10, 4, D + 1, gold);
        for (int z = D; z <= D + 4; z++) set(l, o, 8, -1, z, Blocks.RED_CARPET.defaultBlockState());

        // 4. furnishings
        set(l, o, 8, 0, 1, ModBlocks.WORKING_TV.get().defaultBlockState().setValue(HorizontalDirectionalBlock.FACING, Direction.SOUTH));
        set(l, o, 4, 0, 10, ModBlocks.SMUG_STATUE.get().defaultBlockState().setValue(HorizontalDirectionalBlock.FACING, Direction.SOUTH));
        set(l, o, 12, 0, 10, ModBlocks.SMUG_STATUE.get().defaultBlockState().setValue(HorizontalDirectionalBlock.FACING, Direction.SOUTH));
        set(l, o, 14, 6, 3, ModBlocks.LUXURY_BED.get().defaultBlockState().setValue(HorizontalDirectionalBlock.FACING, Direction.WEST));
        set(l, o, 14, 6, 4, ModBlocks.LUXURY_BED.get().defaultBlockState().setValue(HorizontalDirectionalBlock.FACING, Direction.WEST));
        set(l, o, 13, 6, 3, ModBlocks.LUXURY_BED.get().defaultBlockState().setValue(HorizontalDirectionalBlock.FACING, Direction.WEST));
        set(l, o, 13, 6, 4, ModBlocks.LUXURY_BED.get().defaultBlockState().setValue(HorizontalDirectionalBlock.FACING, Direction.WEST));
        fill(l, o, 5, 6, 2, 11, 6, 9, Blocks.RED_CARPET.defaultBlockState());
        for (int[] t : new int[][]{{3, 1, 1}, {13, 1, 1}, {3, 1, 11}, {13, 1, 11}, {4, 7, 1}, {12, 7, 11}})
            set(l, o, t[0], t[1], t[2], Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, false));

        // 5. remember where everything is
        d.site = o;
        d.doorPos = o.offset(8, 0, D - 1);
        d.partyPos = o.offset(8, 0, D + 4);
        d.trapdoor = o.offset(13, -1, 2);
        d.chair = o.offset(8, -6, 6);
        d.ronSpot = o.offset(8, -5, 3);
        d.smugRoom = o.offset(8, 6, 6);
        d.basementMin = o.offset(3, -6, 2);
        d.basementMax = o.offset(13, -2, 10);
        d.mansionBuilt = true;
        d.setDirty();
    }

    private static void placeDoor(ServerLevel l, BlockPos o, int x, int z) {
        BlockState door = Blocks.BIRCH_DOOR.defaultBlockState().setValue(DoorBlock.FACING, Direction.SOUTH);
        set(l, o, x, 0, z, door.setValue(DoorBlock.HALF, DoubleBlockHalf.LOWER));
        set(l, o, x, 1, z, door.setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER));
        set(l, o, x, 2, z, Blocks.BIRCH_PLANKS.defaultBlockState());
    }

    /** tiny alias so the chair line stays readable. */
    private static final class WoodenChairFacing {
        static final net.minecraft.world.level.block.state.properties.DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
    }
}
