package com.sitandwatch.world;

/** The multi-day escalation cycle. */
public enum Stage {
    DAY1, NIGHT1, DAY2, NIGHT2, DAY3, NIGHT3, DAY4, NIGHT4, POST;

    public boolean atLeast(Stage other) { return this.ordinal() >= other.ordinal(); }
}
