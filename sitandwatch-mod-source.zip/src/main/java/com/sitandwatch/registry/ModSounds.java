package com.sitandwatch.registry;

import com.sitandwatch.SitAndWatch;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, SitAndWatch.MOD_ID);

    private static RegistryObject<SoundEvent> reg(String n) {
        return SOUNDS.register(n, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(SitAndWatch.MOD_ID, n)));
    }

    public static final RegistryObject<SoundEvent> SMUG_TALK = reg("smug_bro_talk");
    public static final RegistryObject<SoundEvent> SMUG_HURT = reg("smug_bro_hurt");
    public static final RegistryObject<SoundEvent> SMUG_DEATH = reg("smug_bro_death");
    public static final RegistryObject<SoundEvent> SMUG_THEME = reg("smug_theme");
    public static final RegistryObject<SoundEvent> OBSESSED_CHEER = reg("obsessed_cheer");
    public static final RegistryObject<SoundEvent> SIT_IN_THE_CHAIR = reg("sit_in_the_chair");
    public static final RegistryObject<SoundEvent> WATCHER_BREATHING = reg("watcher_breathing");
    public static final RegistryObject<SoundEvent> ZIPPER = reg("zipper");
    public static final RegistryObject<SoundEvent> GORE_BURST = reg("gore_burst");
    public static final RegistryObject<SoundEvent> AMBIENCE_LOOP = reg("ambience_loop");
}
