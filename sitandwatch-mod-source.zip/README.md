# Something Wants You To Sit And Watch (Forge 1.20.1)

Fan recreation of the horror mod from LookOut2DD's video. Java 17, Forge 47.3.0, official Mojang mappings.

Build: push to GitHub (the `Build` workflow produces `build/libs/sitandwatch-1.0.0.jar` as an artifact),
or locally with Gradle 8.1.1 + JDK 17: `gradle wrapper --gradle-version 8.1.1 && ./gradlew build`.

Story: Day1 hook -> Night1 mansion + fans circle Smug Bro (theme music) -> Day2 Ron + party trap -> Day3 couch frame-up
-> Night3 angry mob -> Night4 basement ending. Commands (op): `/sitandwatch stage <1-8>`, `/sitandwatch release`, `/sitandwatch reset`.
Models were converted from the supplied .bbmodel files by `tools/` scripts (meshes in assets/sitandwatch/meshes, 2 blocks tall).
